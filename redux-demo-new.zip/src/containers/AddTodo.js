import React from 'react';
import {connect} from 'react-redux';
import AddTodo from "../components/AddTodo";

export default connect()(AddTodo);